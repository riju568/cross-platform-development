import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  bool firebaseInitialized = false;
  try {
    await Firebase.initializeApp();
    firebaseInitialized = true;
  } catch (e) {
    debugPrint("Firebase not configured or offline. Running in Mock Mode: $e");
  }

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
    ),
  );

  runApp(FacebookApp(isFirebaseReady: firebaseInitialized));
}

class FacebookApp extends StatelessWidget {
  final bool isFirebaseReady;
  const FacebookApp({Key? key, required this.isFirebaseReady}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Facebook UI/UX',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: const Color(0xFF1877F2),
        scaffoldBackgroundColor: const Color(0xFFF0F2F5),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1877F2),
          primary: const Color(0xFF1877F2),
        ),
        useMaterial3: true,
      ),
      home: MainFeedScreen(isFirebaseReady: isFirebaseReady),
    );
  }
}

// ==========================================
// DATA MODELS
// ==========================================

class StoryModel {
  final String userName;
  final String userAvatar;
  final String storyImage;
  final bool isAddStory;

  StoryModel({
    required this.userName,
    required this.userAvatar,
    required this.storyImage,
    this.isAddStory = false,
  });
}

class PostModel {
  final String id;
  final String authorName;
  final String authorAvatar;
  final String timeAgo;
  final String content;
  final String? imageUrl;
  final int? bgGradientIndex;
  int likesCount;
  int commentsCount;
  int sharesCount;
  String currentReaction; // 'none', 'like', 'love', 'haha', 'wow', 'sad', 'angry'

  PostModel({
    required this.id,
    required this.authorName,
    required this.authorAvatar,
    required this.timeAgo,
    required this.content,
    this.imageUrl,
    this.bgGradientIndex,
    this.likesCount = 0,
    this.commentsCount = 0,
    this.sharesCount = 0,
    this.currentReaction = 'none',
  });

  factory PostModel.fromMap(String id, Map<String, dynamic> map) {
    return PostModel(
      id: id,
      authorName: map['authorName'] ?? 'Facebook User',
      authorAvatar: map['authorAvatar'] ?? 'https://i.pravatar.cc/150?u=$id',
      timeAgo: map['timeAgo'] ?? 'Just now',
      content: map['content'] ?? '',
      imageUrl: map['imageUrl'],
      bgGradientIndex: map['bgGradientIndex'],
      likesCount: map['likesCount'] ?? 0,
      commentsCount: map['commentsCount'] ?? 0,
      sharesCount: map['sharesCount'] ?? 0,
      currentReaction: map['currentReaction'] ?? 'none',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'authorName': authorName,
      'authorAvatar': authorAvatar,
      'timeAgo': timeAgo,
      'content': content,
      'imageUrl': imageUrl,
      'bgGradientIndex': bgGradientIndex,
      'likesCount': likesCount,
      'commentsCount': commentsCount,
      'sharesCount': sharesCount,
      'currentReaction': currentReaction,
    };
  }
}

// ==========================================
// GRADIENT THEMES FOR POSTS
// ==========================================

final List<List<Color>> postGradients = [
  [], // Standard white background
  [const Color(0xFFFF512F), const Color(0xFFDD2476)], // Sunset
  [const Color(0xFF1A2980), const Color(0xFF26D0CE)], // Ocean
  [const Color(0xFF8E2DE2), const Color(0xFF4A00E0)], // Purple Neon
  [const Color(0xFF11998E), const Color(0xFF38EF7D)], // Mint Green
  [const Color(0xFFFC466B), const Color(0xFF3F5EFB)], // Cyberpunk
];

// ==========================================
// MAIN FEED SCREEN
// ==========================================

class MainFeedScreen extends StatefulWidget {
  final bool isFirebaseReady;
  const MainFeedScreen({Key? key, required this.isFirebaseReady}) : super(key: key);

  @override
  State<MainFeedScreen> createState() => _MainFeedScreenState();
}

class _MainFeedScreenState extends State<MainFeedScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final List<PostModel> _mockPosts = [];

  final List<StoryModel> _stories = [
    StoryModel(
      userName: "Add to Story",
      userAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300",
      storyImage: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300",
      isAddStory: true,
    ),
    StoryModel(
      userName: "David Goggins",
      userAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300",
      storyImage: "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=500",
    ),
    StoryModel(
      userName: "Emma Watson",
      userAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300",
      storyImage: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=500",
    ),
    StoryModel(
      userName: "Alex Rivers",
      userAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300",
      storyImage: "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=500",
    ),
    StoryModel(
      userName: "Sarah Jenkins",
      userAvatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=300",
      storyImage: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=500",
    ),
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 6, vsync: this);
    _initializeMockData();
  }

  void _initializeMockData() {
    _mockPosts.addAll([
      PostModel(
        id: "1",
        authorName: "Aleksa Rakočević",
        authorAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300",
        timeAgo: "2 hrs ago",
        content: "Just designed this interactive Facebook UI/UX in Flutter! 🚀 Try long-pressing the Like button for the floating reaction animation!",
        bgGradientIndex: 3,
        likesCount: 142,
        commentsCount: 28,
        sharesCount: 12,
        currentReaction: 'love',
      ),
      PostModel(
        id: "2",
        authorName: "Flutter Developers",
        authorAvatar: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=300",
        timeAgo: "4 hrs ago",
        content: "Clean architecture, custom overlays, and smooth animations make Flutter the ultimate UI toolkit for cross-platform apps! What are you building today?",
        imageUrl: "https://images.unsplash.com/photo-1551650975-87deedd944c3?w=800",
        likesCount: 523,
        commentsCount: 89,
        sharesCount: 45,
        currentReaction: 'like',
      ),
    ]);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _showCreatePostModal() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => CreatePostModal(
        onPostCreated: (content, gradientIndex) {
          final newPost = PostModel(
            id: DateTime.now().millisecondsSinceEpoch.toString(),
            authorName: "You (Demo User)",
            authorAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300",
            timeAgo: "Just now",
            content: content,
            bgGradientIndex: gradientIndex,
            likesCount: 0,
            commentsCount: 0,
            sharesCount: 0,
          );

          if (widget.isFirebaseReady) {
            FirebaseFirestore.instance.collection('posts').doc(newPost.id).set(newPost.toMap());
          } else {
            setState(() {
              _mockPosts.insert(0, newPost);
            });
          }
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: NestedScrollView(
          headerSliverBuilder: (context, innerBoxIsScrolled) {
            return [
              // Facebook Top App Bar
              SliverAppBar(
                backgroundColor: Colors.white,
                floating: true,
                pinned: true,
                elevation: innerBoxIsScrolled ? 1 : 0,
                title: const Text(
                  'facebook',
                  style: TextStyle(
                    color: Color(0xFF1877F2),
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    letterSpacing: -1.2,
                  ),
                ),
                actions: [
                  _buildCircleButton(Icons.add, _showCreatePostModal),
                  _buildCircleButton(Icons.search, () {}),
                  _buildCircleButton(Icons.messenger_rounded, () {}),
                  const SizedBox(width: 8),
                ],
                bottom: TabBar(
                  controller: _tabController,
                  indicatorColor: const Color(0xFF1877F2),
                  indicatorWeight: 3,
                  labelColor: const Color(0xFF1877F2),
                  unselectedLabelColor: Colors.grey[600],
                  tabs: const [
                    Tab(icon: Icon(Icons.home, size: 28)),
                    Tab(icon: Icon(Icons.ondemand_video, size: 28)),
                    Tab(icon: Icon(Icons.storefront_outlined, size: 28)),
                    Tab(icon: Icon(Icons.groups_outlined, size: 28)),
                    Tab(icon: Icon(Icons.notifications_none, size: 28)),
                    Tab(icon: Icon(Icons.menu, size: 28)),
                  ],
                ),
              ),
            ];
          },
          body: TabBarView(
            controller: _tabController,
            children: [
              _buildHomeFeed(),
              _buildPlaceholderScreen("Video Watch Feed"),
              _buildPlaceholderScreen("Marketplace"),
              _buildPlaceholderScreen("Groups"),
              _buildPlaceholderScreen("Notifications"),
              _buildPlaceholderScreen("Menu & Settings"),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHomeFeed() {
    return CustomScrollView(
      slivers: [
        // Create Post Input Bar
        SliverToBoxAdapter(
          child: Container(
            color: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Column(
              children: [
                Row(
                  children: [
                    const CircleAvatar(
                      radius: 20,
                      backgroundImage: NetworkImage("https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300"),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: GestureDetector(
                        onTap: _showCreatePostModal,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                          decoration: BoxDecoration(
                            color: Colors.grey[200],
                            borderRadius: BorderRadius.circular(24),
                          ),
                          child: Text(
                            "What's on your mind?",
                            style: TextStyle(color: Colors.grey[600], fontSize: 16),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const Divider(height: 24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildActionChip(Icons.videocam, Colors.red, "Live"),
                    _buildActionChip(Icons.photo_library, Colors.green, "Photo"),
                    _buildActionChip(Icons.emoji_emotions, Colors.amber, "Feeling"),
                  ],
                ),
              ],
            ),
          ),
        ),

        const SliverToBoxAdapter(child: SizedBox(height: 8)),

        // Stories Rail
        SliverToBoxAdapter(
          child: Container(
            height: 210,
            color: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: _stories.length,
              itemBuilder: (context, index) => _buildStoryCard(_stories[index]),
            ),
          ),
        ),

        const SliverToBoxAdapter(child: SizedBox(height: 8)),

        // Posts Stream / List
        widget.isFirebaseReady ? _buildFirestoreFeed() : _buildMockFeed(),
      ],
    );
  }

  Widget _buildFirestoreFeed() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('posts').orderBy('id', descending: true).snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const SliverFillRemaining(child: Center(child: CircularProgressIndicator()));
        }
        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return _buildMockFeed(); // Fallback if database is empty
        }

        final posts = snapshot.data!.docs.map((doc) {
          return PostModel.fromMap(doc.id, doc.data() as Map<String, dynamic>);
        }).toList();

        return SliverList(
          delegate: SliverChildBuilderDelegate(
            (context, index) => PostCard(
              post: posts[index],
              onReactionChanged: (newReaction) {
                FirebaseFirestore.instance.collection('posts').doc(posts[index].id).update({
                  'currentReaction': newReaction,
                  'likesCount': newReaction == 'none' ? posts[index].likesCount - 1 : posts[index].likesCount + 1,
                });
              },
            ),
            childCount: posts.length,
          ),
        );
      },
    );
  }

  Widget _buildMockFeed() {
    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (context, index) => PostCard(
          post: _mockPosts[index],
          onReactionChanged: (newReaction) {
            setState(() {
              if (_mockPosts[index].currentReaction == 'none' && newReaction != 'none') {
                _mockPosts[index].likesCount++;
              } else if (_mockPosts[index].currentReaction != 'none' && newReaction == 'none') {
                _mockPosts[index].likesCount--;
              }
              _mockPosts[index].currentReaction = newReaction;
            });
          },
        ),
        childCount: _mockPosts.length,
      ),
    );
  }

  Widget _buildStoryCard(StoryModel story) {
    return Container(
      width: 110,
      margin: const EdgeInsets.symmetric(horizontal: 4),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        image: DecorationImage(
          image: NetworkImage(story.storyImage),
          fit: BoxFit.cover,
        ),
      ),
      child: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Colors.black.withOpacity(0.1), Colors.black.withOpacity(0.7)],
              ),
            ),
          ),
          Positioned(
            top: 8,
            left: 8,
            child: story.isAddStory
                ? Container(
                    width: 36,
                    height: 36,
                    decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                    child: const Icon(Icons.add, color: Color(0xFF1877F2)),
                  )
                : Container(
                    padding: const EdgeInsets.all(2),
                    decoration: const BoxDecoration(color: Color(0xFF1877F2), shape: BoxShape.circle),
                    child: CircleAvatar(
                      radius: 16,
                      backgroundImage: NetworkImage(story.userAvatar),
                    ),
                  ),
          ),
          Positioned(
            bottom: 8,
            left: 8,
            right: 8,
            child: Text(
              story.userName,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCircleButton(IconData icon, VoidCallback onPressed) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 4),
      decoration: BoxDecoration(color: Colors.grey[200], shape: BoxShape.circle),
      child: IconButton(
        icon: Icon(icon, color: Colors.black87, size: 22),
        onPressed: onPressed,
      ),
    );
  }

  Widget _buildActionChip(IconData icon, Color color, String label) {
    return InkWell(
      onTap: () {},
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
        child: Row(
          children: [
            Icon(icon, color: color, size: 24),
            const SizedBox(width: 6),
            Text(label, style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.black87)),
          ],
        ),
      ),
    );
  }

  Widget _buildPlaceholderScreen(String title) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.construction, size: 64, color: Colors.grey[400]),
          const SizedBox(height: 16),
          Text(title, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.grey[600])),
          const SizedBox(height: 8),
          const Text("Switch to the Home tab to test the interactive feed!", style: TextStyle(color: Colors.grey)),
        ],
      ),
    );
  }
}

// ==========================================
// INTERACTIVE POST CARD WITH REACTION DOCK
// ==========================================

class PostCard extends StatefulWidget {
  final PostModel post;
  final Function(String) onReactionChanged;

  const PostCard({Key? key, required this.post, required this.onReactionChanged}) : super(key: key);

  @override
  State<PostCard> createState() => _PostCardState();
}

class _PostCardState extends State<PostCard> {
  OverlayEntry? _overlayEntry;
  final LayerLink _layerLink = LayerLink();

  final Map<String, Map<String, dynamic>> reactions = {
    'like': {'emoji': '👍', 'label': 'Like', 'color': Color(0xFF1877F2)},
    'love': {'emoji': '❤️', 'label': 'Love', 'color': Color(0xFFE0245E)},
    'haha': {'emoji': '😆', 'label': 'Haha', 'color': Color(0xFFF7B125)},
    'wow': {'emoji': '😮', 'label': 'Wow', 'color': Color(0xFFF7B125)},
    'sad': {'emoji': '😢', 'label': 'Sad', 'color': Color(0xFFF7B125)},
    'angry': {'emoji': '😡', 'label': 'Angry', 'color': Color(0xFFE0245E)},
  };

  void _showReactionDock() {
    _overlayEntry = _createOverlayEntry();
    Overlay.of(context).insert(_overlayEntry!);
  }

  void _hideReactionDock() {
    _overlayEntry?.remove();
    _overlayEntry = null;
  }

  OverlayEntry _createOverlayEntry() {
    RenderBox renderBox = context.findRenderObject() as RenderBox;
    var size = renderBox.size;

    return OverlayEntry(
      builder: (context) => Stack(
        children: [
          GestureDetector(
            onTap: _hideReactionDock,
            behavior: HitTestBehavior.translucent,
            child: Container(color: Colors.transparent),
          ),
          Positioned(
            width: 280,
            child: CompositedTransformFollower(
              link: _layerLink,
              showWhenUnlinked: false,
              offset: Offset(0, -60), // Above the like button
              child: Material(
                elevation: 8,
                borderRadius: BorderRadius.circular(30),
                color: Colors.white,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: reactions.entries.map((entry) {
                      return _buildReactionIcon(entry.key, entry.value['emoji']);
                    }).toList(),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildReactionIcon(String key, String emoji) {
    return TweenAnimationBuilder(
      duration: const Duration(milliseconds: 200),
      tween: Tween<double>(begin: 0.8, end: 1.0),
      builder: (context, double scale, child) {
        return Transform.scale(
          scale: scale,
          child: GestureDetector(
            onTap: () {
              widget.onReactionChanged(key);
              _hideReactionDock();
            },
            child: Container(
              padding: const EdgeInsets.all(6),
              child: Text(emoji, style: const TextStyle(fontSize: 26)),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool hasBgGradient = widget.post.bgGradientIndex != null && widget.post.bgGradientIndex! > 0;
    final currentReactionData = reactions[widget.post.currentReaction];

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      color: Colors.white,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Author Header
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 20,
                  backgroundImage: NetworkImage(widget.post.authorAvatar),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(widget.post.authorName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      Row(
                        children: [
                          Text(widget.post.timeAgo, style: TextStyle(color: Colors.grey[600], fontSize: 12)),
                          const SizedBox(width: 4),
                          Icon(Icons.public, size: 14, color: Colors.grey[600]),
                        ],
                      ),
                    ],
                  ),
                ),
                IconButton(icon: const Icon(Icons.more_horiz), onPressed: () {}),
              ],
            ),
          ),

          // Post Content / Status Background
          if (hasBgGradient)
            Container(
              width: double.infinity,
              height: 220,
              padding: const EdgeInsets.all(24),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: postGradients[widget.post.bgGradientIndex!],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Text(
                widget.post.content,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
              ),
            )
          else
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              child: Text(widget.post.content, style: const TextStyle(fontSize: 15)),
            ),

          // Post Image
          if (widget.post.imageUrl != null)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Image.network(
                widget.post.imageUrl!,
                width: double.infinity,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => const SizedBox(),
              ),
            ),

          // Engagement Counters
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: const BoxDecoration(color: Color(0xFF1877F2), shape: BoxShape.circle),
                  child: const Icon(Icons.thumb_up, size: 10, color: Colors.white),
                ),
                const SizedBox(width: 4),
                Text("${widget.post.likesCount}", style: TextStyle(color: Colors.grey[600])),
                const Spacer(),
                Text("${widget.post.commentsCount} comments", style: TextStyle(color: Colors.grey[600])),
                const SizedBox(width: 12),
                Text("${widget.post.sharesCount} shares", style: TextStyle(color: Colors.grey[600])),
              ],
            ),
          ),

          const Divider(height: 1),

          // Interactive Action Buttons
          CompositedTransformTarget(
            link: _layerLink,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                // LIKE BUTTON WITH LONG-PRESS FUNCTIONALITY
                Expanded(
                  child: GestureDetector(
                    onLongPress: _showReactionDock,
                    onTap: () {
                      if (widget.post.currentReaction == 'none') {
                        widget.onReactionChanged('like');
                      } else {
                        widget.onReactionChanged('none');
                      }
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          if (currentReactionData != null) ...[
                            Text(currentReactionData['emoji'], style: const TextStyle(fontSize: 18)),
                            const SizedBox(width: 6),
                            Text(
                              currentReactionData['label'],
                              style: TextStyle(color: currentReactionData['color'], fontWeight: FontWeight.bold),
                            ),
                          ] else ...[
                            Icon(Icons.thumb_up_outlined, color: Colors.grey[600], size: 20),
                            const SizedBox(width: 6),
                            Text("Like", style: TextStyle(color: Colors.grey[600], fontWeight: FontWeight.w600)),
                          ],
                        ],
                      ),
                    ),
                  ),
                ),

                _buildActionButton(Icons.chat_bubble_outline, "Comment", () {}),
                _buildActionButton(Icons.share_outlined, "Share", () {}),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton(IconData icon, String label, VoidCallback onTap) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: Colors.grey[600], size: 20),
              const SizedBox(width: 6),
              Text(label, style: TextStyle(color: Colors.grey[600], fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ),
    );
  }
}

// ==========================================
// CREATE POST MODAL BOTTOM SHEET
// ==========================================

class CreatePostModal extends StatefulWidget {
  final Function(String content, int? gradientIndex) onPostCreated;

  const CreatePostModal({Key? key, required this.onPostCreated}) : super(key: key);

  @override
  State<CreatePostModal> createState() => _CreatePostModalState();
}

class _CreatePostModalState extends State<CreatePostModal> {
  final TextEditingController _controller = TextEditingController();
  int _selectedGradient = 0;

  @override
  Widget build(BuildContext context) {
    final bool hasGradient = _selectedGradient > 0;

    return Container(
      height: MediaQuery.of(context).size.height * 0.85,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.pop(context),
                ),
                const Text("Create Post", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF1877F2),
                    foregroundColor: Colors.white,
                    elevation: 0,
                  ),
                  onPressed: () {
                    if (_controller.text.trim().isNotEmpty) {
                      widget.onPostCreated(_controller.text.trim(), _selectedGradient);
                      Navigator.pop(context);
                    }
                  },
                  child: const Text("Post"),
                ),
              ],
            ),
          ),
          const Divider(height: 1),

          // User Info
          const Padding(
            padding: EdgeInsets.all(16),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 22,
                  backgroundImage: NetworkImage("https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300"),
                ),
                SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("You (Demo User)", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(Icons.group, size: 14, color: Colors.grey),
                        SizedBox(width: 4),
                        Text("Friends", style: TextStyle(color: Colors.grey, fontSize: 12)),
                      ],
                    )
                  ],
                ),
              ],
            ),
          ),

          // Text / Gradient Area
          Expanded(
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              padding: EdgeInsets.all(hasGradient ? 24 : 0),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                gradient: hasGradient
                    ? LinearGradient(
                        colors: postGradients[_selectedGradient],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      )
                    : null,
              ),
              alignment: hasGradient ? Alignment.center : Alignment.topStart,
              child: TextField(
                controller: _controller,
                maxLines: null,
                textAlign: hasGradient ? TextAlign.center : TextAlign.start,
                style: TextStyle(
                  fontSize: hasGradient ? 24 : 18,
                  fontWeight: hasGradient ? FontWeight.bold : FontWeight.normal,
                  color: hasGradient ? Colors.white : Colors.black87,
                ),
                decoration: InputDecoration(
                  hintText: "What's on your mind?",
                  hintStyle: TextStyle(
                    color: hasGradient ? Colors.white70 : Colors.grey[400],
                  ),
                  border: InputBorder.none,
                ),
              ),
            ),
          ),

          // Gradient Background Selector
          Container(
            height: 50,
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: postGradients.length,
              itemBuilder: (context, index) {
                final isSelected = _selectedGradient == index;
                return GestureDetector(
                  onTap: () => setState(() => _selectedGradient = index),
                  child: Container(
                    width: 36,
                    height: 36,
                    margin: const EdgeInsets.only(right: 8),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: isSelected ? Border.all(color: Colors.black, width: 2) : null,
                      color: index == 0 ? Colors.grey[200] : null,
                      gradient: index > 0
                          ? LinearGradient(colors: postGradients[index], begin: Alignment.topLeft, end: Alignment.bottomRight)
                          : null,
                    ),
                    child: index == 0 ? const Icon(Icons.format_color_reset, size: 18, color: Colors.grey) : null,
                  ),
                );
              },
            ),
          ),

          const Divider(height: 1),

          // Action Options
          ListTile(
            leading: const Icon(Icons.photo_library, color: Colors.green),
            title: const Text("Photo/Video"),
            onTap: () {},
          ),
          ListTile(
            leading: const Icon(Icons.person_add, color: Colors.blue),
            title: const Text("Tag people"),
            onTap: () {},
          ),
          ListTile(
            leading: const Icon(Icons.emoji_emotions, color: Colors.amber),
            title: const Text("Feeling/Activity"),
            onTap: () {},
          ),
        ],
      ),
    );
  }
}