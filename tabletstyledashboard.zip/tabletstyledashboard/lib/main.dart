import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flame/game.dart';
import 'package:flame/components.dart';
import 'package:flame/events.dart';
import 'package:flame/particles.dart';

void main() {
  runApp(const FlameVibeApp());
}

class FlameVibeApp extends StatelessWidget {
  const FlameVibeApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flame Engine Canvas',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0F172A), // Slate 900
        primaryColor: const Color(0xFFF97316), // Orange 500
      ),
      home: const MainTabShell(),
    );
  }
}

// _______________________________________
// RESPONSIVE MOBILE / TABLET SHELL
// _______________________________________
class MainTabShell extends StatefulWidget {
  const MainTabShell({Key? key}) : super(key: key);

  @override
  State<MainTabShell> createState() => _MainTabShellState();
}

class _MainTabShellState extends State<MainTabShell> {
  int _currentTab = 0;
  late RealtimeFlameGame _flameGame;

  @override
  void initState() {
    super.initState();
    _flameGame = RealtimeFlameGame();
  }

  @override
  Widget build(BuildContext context) {
    final Size screenSize = MediaQuery.of(context).size;
    final bool isTablet = screenSize.width > 768;

    return Scaffold(
      body: Row(
        children: [
          // Adaptive Navigation: Sidebar for Tablets, BottomBar for Mobile
          if (isTablet) _buildSidebar(),
          
          Expanded(
            child: Column(
              children: [
                _buildHeader(isTablet),
                Expanded(
                  child: IndexedStack(
                    index: _currentTab,
                    children: [
                      // TAB 0: Active Flame Game Canvas
                      ClipRRect(
                        borderRadius: BorderRadius.circular(isTablet ? 16 : 0),
                        child: Container(
                          margin: EdgeInsets.all(isTablet ? 16 : 0),
                          decoration: BoxDecoration(
                            border: Border.all(color: const Color(0xFF334155), width: 2),
                            borderRadius: BorderRadius.circular(isTablet ? 16 : 0),
                          ),
                          child: GameWidget(game: _flameGame),
                        ),
                      ),
                      // TAB 1: Live Engine Telemetry
                      _buildTelemetryTab(),
                      // TAB 2: System Upgrades
                      _buildConfigurationTab(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: !isTablet
          ? BottomNavigationBar(
              currentIndex: _currentTab,
              onTap: (index) => setState(() => _currentTab = index),
              backgroundColor: const Color(0xFF1E293B),
              selectedItemColor: const Color(0xFFF97316),
              unselectedItemColor: Colors.slate.shade400,
              items: const [
                BottomNavigationBarItem(icon: Icon(Icons.gamepad), label: 'Engine'),
                BottomNavigationBarItem(icon: Icon(Icons.analytics), label: 'Telemetry'),
                BottomNavigationBarItem(icon: Icon(Icons.tune), label: 'Config'),
              ],
            )
          : null,
    );
  }

  Widget _buildHeader(bool isTablet) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
      color: const Color(0xFF1E293B),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _currentTab == 0 ? "PLASMA KINETICS" : _currentTab == 1 ? "DIAGNOSTICS" : "CORE MANAGEMENT",
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.black, letterSpacing: 1.5, color: Color(0xFFF97316)),
              ),
              const Text("Flame Engine v1.18 Runtime Architecture", style: TextStyle(color: Colors.slate, fontSize: 12)),
            ],
          ),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFEF4444)),
            onPressed: () => _flameGame.resetCanvas(),
            icon: const Icon(Icons.refresh, color: Colors.white),
            label: const Text("RESET CORE", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          )
        ],
      ),
    );
  }

  Widget _buildSidebar() {
    return Container(
      width: 260,
      color: const Color(0xFF1E293B),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.all(24),
            child: Row(
              children: [
                Icon(Icons.local_fire_department, color: Color(0xFFF97316), size: 32),
                SizedBox(width: 12),
                Text("FLAME.IO", style: TextStyle(fontSize: 22, fontWeight: FontWeight.black, letterSpacing: 1)),
              ],
            ),
          ),
          const Divider(color: Color(0xFF334155)),
          const SizedBox(height: 16),
          _sidebarTile(0, Icons.gamepad, "Engine Canvas"),
          _sidebarTile(1, Icons.analytics, "System Telemetry"),
          _sidebarTile(2, Icons.tune, "Configurations"),
        ],
      ),
    );
  }

  Widget _sidebarTile(int index, IconData icon, String label) {
    final bool isSelected = _currentTab == index;
    return ListTile(
      selected: isSelected,
      selectedTileColor: const Color(0xFF334155),
      leading: Icon(icon, color: isSelected ? const Color(0xFFF97316) : Colors.slate),
      title: Text(label, style: TextStyle(color: isSelected ? Colors.white : Colors.slate, fontWeight: FontWeight.w600)),
      onTap: () => setState(() => _currentTab = index),
    );
  }

  Widget _buildTelemetryTab() {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _infoCard("GPU Canvas State", "Active & Rendering via Skia Pipeline"),
          const SizedBox(height: 16),
          _infoCard("Target Physics Refresh", "60 FPS Hardware Synchronized"),
          const SizedBox(height: 16),
          _infoCard("Vector Particle Instantiation Engine", "Dynamic Vector Array Generation Model"),
        ],
      ),
    );
  }

  Widget _buildConfigurationTab() {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("Engine Constraints Selector", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          SwitchListTile(
            title: const Text("Vector Plasma Overclocking"),
            subtitle: const Text("Enhances physics thermal simulations on tap actions"),
            value: true,
            activeColor: const Color(0xFFF97316),
            onChanged: (val) {},
          )
        ],
      ),
    );
  }

  Widget _infoCard(String title, String desc) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: const Color(0xFF1E293B), borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white)),
          const SizedBox(height: 4),
          Text(desc, style: const TextStyle(color: Colors.slate)),
        ],
      ),
    );
  }
}

// _______________________________________
// FLAME ENGINE HARDWARE GAME GRAPHIC LAYER
// _______________________________________
class RealtimeFlameGame extends FlameGame with DragCallbacks, TapCallbacks {
  late VectorPlasmaCore plasmaCore;
  final math.Random _rng = math.Random();

  @override
  Color backgroundColor() => const Color(0xFF020617); // Deep slate space background

  @override
  Future<void> onLoad() async {
    plasmaCore = VectorPlasmaCore()
      ..position = size / 2
      ..anchor = Anchor.center;
    add(plasmaCore);
    add(
      TextComponent(
        text: 'TAP OR DRAG ON SCREEN TO EMIT FLAME PARTICLES',
        textRenderer: TextPaint(
          style: const TextStyle(
            fontSize: 13,
            color: Color(0xFF64748B),
            fontWeight: FontWeight.bold,
            letterSpacing: 2,
          ),
        ),
      )
        ..anchor = Anchor.center
        ..position = Vector2(size.x / 2, size.y - 40),
    );
  }

  @override
  void onTapDown(TapDownEvent event) {
    _createPlasmaBurst(event.localPosition);
    plasmaCore.targetPosition = event.localPosition;
  }

  @override
  void onDragUpdate(DragUpdateEvent event) {
    plasmaCore.targetPosition = event.localEndPosition;
    _createPlasmaBurst(event.localEndPosition);
  }

  void resetCanvas() {
    plasmaCore.position = size / 2;
    plasmaCore.targetPosition = size / 2;
  }
  void _createPlasmaBurst(Vector2 systemOrigin) {
    final particleList = List.generate(12, (index) {
      final double angle = _rng.nextDouble() * math.pi * 2;
      final double speed = 40.0 + _rng.nextDouble() * 120.0;
      final double sizeScale = 4.0 + _rng.nextDouble() * 8.0;

      return MovingParticle(
        curve: Curves.easeOutCubic,
        from: systemOrigin,
        to: systemOrigin + Vector2(math.cos(angle) * speed, math.sin(angle) * speed),
        child: ComponentParticle(
          component: CustomFireEmber(
            radius: sizeScale,
            color: index % 3 == 0 
                ? const Color(0xFFEF4444) // Fire Red
                : index % 3 == 1 
                    ? const Color(0xFFF97316) // Fire Orange
                    : const Color(0xFFFACC15), // Incandescent Yellow
          ),
        ),
      );
    });

    add(ParticleSystemComponent(
      particle: Particle.generate(
        count: 12,
        lifespan: 0.6,
        generator: (i) => particleList[i],
      ),
    ));
  }
}

// _______________________________________
// VECTOR GRAPHICS RENDER MODULES
// _______________________________________
class VectorPlasmaCore extends PositionComponent {
  Vector2 targetPosition = Vector2.zero();
  final double structuralSpeed = 6.5;

  VectorPlasmaCore() {
    size = Vector2(50, 50);
  }

  @override
  void onMount() {
    super.onMount();
    targetPosition = position.clone();
  }

  @override
  void update(double dt) {
    super.update(dt);
    // Smooth kinematic interpolation vector mechanics
    position.lerp(targetPosition, structuralSpeed * dt);
  }

  @override
  void render(Canvas canvas) {
    final centerPoint = Offset(size.x / 2, size.y / 2);
    final Paint ringPaint = Paint()
      ..color = const Color(0xFF38BDF8).withOpacity(0.3)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;
    canvas.drawCircle(centerPoint, 24, ringPaint);

    // Draw central engine matrix core geometry
    final Paint corePaint = Paint()
      ..gradient = const RadialGradient(
        colors: [Colors.white, Color(0xFFF97316), Colors.transparent],
      ).createShader(Rect.fromCircle(center: centerPoint, radius: 14));
    
    canvas.drawCircle(centerPoint, 14, corePaint);
  }
}
class CustomFireEmber extends PositionComponent {
  final double radius;
  final Color color;

  CustomFireEmber({required this.radius, required this.color});

  @override
  void render(Canvas canvas) {
    final Paint paint = Paint()
      ..color = color
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3.0); // Procedural bloom glow filter
    
    canvas.drawCircle(Offset.zero, radius, paint);
  }
}